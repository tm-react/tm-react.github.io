echo "Welcome to React Mono Repo Project";
echo "-------------------------------------------------------------"
echo "-------------------------------------------------------------"

cd ../modules

echo "Cloning TM React Project From GitHub";
git clone https://github.com/hmtmcse/tm-react.git


echo "Cloning React MUI UI Project From GitHub";
git clone https://github.com/hmtmcse/react-mui-ui.git 